package com.jarvis.mobile;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int AUDIO=101, SPEECH=102;
    TextView reply,status; EditText input; TextToSpeech tts;
    int bg=Color.rgb(5,11,19), cyan=Color.rgb(84,234,255);
    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
      tts=new TextToSpeech(this,r->{if(r==TextToSpeech.SUCCESS)tts.setLanguage(Locale.US);}); build();}
    TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    void build(){ScrollView sc=new ScrollView(this);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(22,24,22,24);l.setBackgroundColor(bg);sc.addView(l);setContentView(sc);
      TextView a=label("STARK SYSTEMS / MOBILE",12,cyan,true);a.setGravity(17);l.addView(a);
      TextView title=label("J.A.R.V.I.S.",32,Color.rgb(223,250,255),false);title.setGravity(17);title.setPadding(0,14,0,0);l.addView(title);
      TextView sub=label("PERSONAL AI INTERFACE",11,Color.rgb(138,182,200),true);sub.setGravity(17);l.addView(sub);
      TextView core=label("◉",72,cyan,true);core.setGravity(17);l.addView(core);
      status=label("● SYSTEM READY",12,cyan,true);status.setGravity(17);l.addView(status);
      reply=label("Hello. I am JARVIS. Enter a command or activate voice.",15,Color.rgb(223,250,255),false);reply.setPadding(14,16,14,16);reply.setBackgroundColor(Color.rgb(7,23,39));l.addView(reply);
      input=new EditText(this);input.setHint("Type a command in English…");input.setTextColor(-1);input.setHintTextColor(Color.LTGRAY);input.setSingleLine(true);input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=18;l.addView(input,p);
      button(l,"SEND COMMAND",v->run(input.getText().toString()));button(l,"◉ ACTIVATE VOICE",v->voice());button(l,"OPEN YOUTUBE",v->open("https://m.youtube.com"));button(l,"OPEN GOOGLE",v->open("https://www.google.com"));
      TextView note=label("Voice needs microphone permission. This prototype cannot control every Android feature.",10,Color.rgb(138,182,200),false);note.setGravity(17);note.setPadding(0,16,0,0);l.addView(note);}
    void button(LinearLayout l,String text,View.OnClickListener c){Button b=new Button(this);b.setText(text);b.setTextColor(-1);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(12,75,103)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=8;l.addView(b,p);b.setOnClickListener(c);}
    void say(String s){reply.setText(s);status.setText("● READY");if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
    void run(String raw){String c=raw.trim().toLowerCase(Locale.ROOT);if(c.isEmpty()){say("Please enter a command.");return;}
      if(c.contains("time"))say("The current time is "+DateFormat.getTimeInstance().format(new Date())+".");
      else if(c.contains("date")||c.contains("today"))say("Today is "+DateFormat.getDateInstance(DateFormat.FULL).format(new Date())+".");
      else if(c.contains("youtube")){say("Opening YouTube.");open("https://m.youtube.com");}
      else if(c.contains("google")){say("Opening Google.");open("https://www.google.com");}
      else if(c.contains("battery"))say("Open Android Settings, then Battery, to check battery status.");
      else if(c.contains("help")||c.contains("command"))say("Try: time, date, open YouTube, open Google, or battery help.");
      else say("I heard: "+raw+". This starter app has a few demo commands. More phone actions require explicit Android permissions.");}
    void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Could not open link",0).show();}}
    void voice(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},AUDIO);return;}launchSpeech();}
    void launchSpeech(){try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak a command for JARVIS");startActivityForResult(i,SPEECH);}catch(Exception e){say("Voice unavailable. You can type commands.");}}
    public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)launchSpeech();else if(r==AUDIO)say("Microphone permission not granted.");}
    protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==SPEECH&&result==RESULT_OK&&data!=null){ArrayList<String>a=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty()){input.setText(a.get(0));run(a.get(0));}}}
    protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
