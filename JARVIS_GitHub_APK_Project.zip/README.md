# JARVIS Mobile — GitHub Actions APK starter

Native Android starter app: dark sci-fi UI, text commands, Android speech recognition, spoken replies, and buttons to open YouTube/Google.

## Build using GitHub on your phone
1. Create a repository on https://github.com/new (e.g. `jarvis-mobile`).
2. Extract this ZIP on your phone.
3. Upload the *contents* of this folder to the repository root, including `.github/workflows/build.yml`.
4. Open the repository's Actions tab and enable Actions if prompted.
5. Choose **Build JARVIS APK** → **Run workflow**. A push to `main` also triggers the build.
6. When the run succeeds, open it and download the **JARVIS-debug-APK** artifact.
7. Extract that downloaded ZIP, tap `app-debug.apk`, and allow installation from that source if Android asks.

## Limits
This is a starter app, not a full AI assistant. Voice recognition may use Google's speech service and may need internet. Demo commands: time, date, open YouTube, open Google, help, battery help. It is not connected to Gemini and cannot control every phone feature. More actions require implementation and Android permissions. The APK is a debug build, not a Play Store release.
